import javax.*;
import java.*;

public class Player
  {
    public String name;
     public int[] numHits;
}
